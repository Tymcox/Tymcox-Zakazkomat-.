# ZAKÁZKOMAT

Připravené MVP pro Cloudflare Pages. Začněte podle `DEPLOYMENT-CZ.md`.

- Frontend: `index.html`
- Backend endpoint: `functions/api/lead.js` (`POST /api/lead`)
- Databázové schéma: `schema.sql`
- Příklad konfigurace: `wrangler.toml.example`

Upozornění: databáze, Cloudflare binding a nasazení musí být nakonfigurovány v účtu vlastníka. Neobsahuje admin rozhraní ani automatické rozesílání zakázek.
