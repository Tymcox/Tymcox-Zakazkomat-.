# ZAKÁZKOMAT: MVP pro Cloudflare Pages

## Obsah balíčku
- `index.html`: responzivní veřejný web a poptávkový formulář.
- `functions/api/lead.js`: Cloudflare Pages Function pro validaci a ukládání poptávek.
- `schema.sql`: databázové schéma pro Cloudflare D1.
- `ochrana-udaju.html`: pracovní šablona, nikoli finální právní dokument.
- `wrangler.toml.example`: příklad konfigurace.

## Nasazení
1. Nahrajte obsah tohoto ZIPu do kořenové složky repozitáře `Tymcox/Zakazkomat-`. Soubory `index.html`, `functions/` a `schema.sql` musí být přímo v kořeni projektu, ne v další vnořené složce.
2. V Cloudflare otevřete Workers & Pages a vytvořte Pages projekt propojený s GitHub repozitářem.
3. Nastavte build command na prázdný (bez build kroku) a Build output directory na `.`.
4. V Cloudflare D1 vytvořte databázi `zakazkomat`.
5. V D1 konzoli spusťte celý obsah `schema.sql`.
6. V Pages projektu otevřete Settings → Functions → D1 database bindings a přidejte binding `DB` odkazující na databázi `zakazkomat`.
7. Uložte nastavení a spusťte nové nasazení.

## Ověření
- Otevřete veřejnou adresu Pages projektu.
- Odešlete testovací poptávku.
- V D1 konzoli ověřte záznam:
  `SELECT id, name, email, category, status, created_at FROM leads ORDER BY created_at DESC LIMIT 10;`
- API při chybějícím D1 bindingu vrací HTTP 503. Při úspěšném uložení vrací JSON s `ok: true` a ID poptávky.

## Co není hotové
Toto je první funkční základ MVP, nikoli kompletní tržiště. Zatím chybí:
- registrace a přihlašování zákazníků a firem,
- profily a ověřování firem,
- zabezpečená administrace a správa zakázek,
- automatické párování a rozesílání poptávek,
- transakční e-maily a notifikace,
- plná lokalizace CZ/EN/DE,
- ochrana proti zahlcení API na úrovni provozní infrastruktury a monitoring.

## Před veřejným ostrým provozem
- Doplňte úplné a ověřené identifikační údaje provozovatele včetně sídla a kontaktního telefonu.
- Nechte právně zkontrolovat zásady ochrany osobních údajů, dobu uchování, právní titul a předávání kontaktů firmám.
- Ověřte text souhlasu podle skutečného způsobu zpracování.
- Otestujte ukládání, chybové stavy a zálohování databáze.
- Nikdy nevkládejte API tokeny ani tajné klíče do repozitáře.

## Důležité
Vytvoření databáze, přidání D1 bindingu a produkční nasazení vyžadují přístup do Cloudflare účtu vlastníka. Samotný ZIP ani veřejný GitHub repozitář tyto kroky neprovedou.
