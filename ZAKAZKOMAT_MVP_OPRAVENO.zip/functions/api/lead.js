const CATEGORIES = new Set([
  "Vzduchotechnika a klimatizace",
  "Ocelové konstrukce a montáže",
  "Stavební práce a rekonstrukce",
  "Jiné"
]);

function reply(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff"
    }
  });
}

function field(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function onRequestPost({ request, env }) {
  if (!env.DB) return reply({ error: "Databáze není připojena. Správce musí nakonfigurovat Cloudflare D1 binding DB." }, 503);

  const origin = request.headers.get("Origin");
  if (origin) {
    try {
      if (new URL(origin).host !== new URL(request.url).host) return reply({ error: "Nepovolený původ požadavku." }, 403);
    } catch { return reply({ error: "Neplatný původ požadavku." }, 403); }
  }

  if (!(request.headers.get("content-type") || "").toLowerCase().includes("application/json")) {
    return reply({ error: "Požadavek musí být ve formátu JSON." }, 415);
  }

  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > 12000) return reply({ error: "Odeslaná data jsou příliš velká." }, 413);

  let body;
  try {
    const raw = await request.text();
    if (raw.length > 12000) return reply({ error: "Odeslaná data jsou příliš velká." }, 413);
    body = JSON.parse(raw);
  } catch { return reply({ error: "Neplatná data formuláře." }, 400); }

  // Hidden honeypot field. Bots that fill it receive a harmless success response.
  if (field(body.website, 200)) return reply({ ok: true });

  const name = field(body.name, 120);
  const phone = field(body.phone, 40);
  const email = field(body.email, 254).toLowerCase();
  const place = field(body.place, 160);
  const category = field(body.category, 100);
  const description = field(body.description, 5000);
  const consent = body.consent === true || body.consent === "on" || body.consent === "true";

  if (!name || !phone || !email || !place || !category || !description || !consent) {
    return reply({ error: "Vyplňte všechna povinná pole a potvrďte informace o zpracování údajů." }, 400);
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply({ error: "Zkontrolujte e-mailovou adresu." }, 400);
  if (!CATEGORIES.has(category)) return reply({ error: "Vybraný obor není platný." }, 400);

  const id = crypto.randomUUID();
  try {
    await env.DB.prepare(`
      INSERT INTO leads (id, name, phone, email, place, category, description, consent, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'new', datetime('now'))
    `).bind(id, name, phone, email, place, category, description).run();
    return reply({ ok: true, id });
  } catch (error) {
    console.error("Lead insert failed", error);
    return reply({ error: "Poptávku se nepodařilo uložit. Zkuste to později." }, 500);
  }
}

export async function onRequestGet() {
  return reply({ error: "Metoda není povolena." }, 405);
}
